from flask import Flask, render_template, render_template_string, request, jsonify, send_file
import numpy as np
import math, random, cv2, tempfile

app = Flask(__name__)

# ====================================
# D15 Test Code
# ====================================
cap_data = [
    {"CapNo": "pilot", "Munsell": "10B 5/6", "xC": 0.228, "yC": 0.254, "R": 93,  "G": 130, "B": 160},
    {"CapNo": "1",     "Munsell": "5B 5/4",    "xC": 0.235, "yC": 0.277, "R": 99,  "G": 130, "B": 143},
    {"CapNo": "2",     "Munsell": "10BG 5/4",  "xC": 0.247, "yC": 0.301, "R": 96,  "G": 132, "B": 137},
    {"CapNo": "3",     "Munsell": "5BG 5/4",   "xC": 0.254, "yC": 0.322, "R": 97,  "G": 133, "B": 128},
    {"CapNo": "4",     "Munsell": "10G 5/4",   "xC": 0.264, "yC": 0.346, "R": 99,  "G": 133, "B": 119},
    {"CapNo": "5",     "Munsell": "5G 5/4",    "xC": 0.278, "yC": 0.375, "R": 102, "G": 133, "B": 111},
    {"CapNo": "6",     "Munsell": "10GY 5/4",  "xC": 0.312, "yC": 0.397, "R": 109, "G": 132, "B": 98},
    {"CapNo": "7",     "Munsell": "5GY 5/4",   "xC": 0.350, "yC": 0.412, "R": 119, "G": 128, "B": 84},
    {"CapNo": "8",     "Munsell": "5Y 5/4",    "xC": 0.390, "yC": 0.406, "R": 134, "G": 122, "B": 76},
    {"CapNo": "9",     "Munsell": "10YR 5/4",  "xC": 0.407, "yC": 0.388, "R": 140, "G": 117, "B": 82},
    {"CapNo": "10",    "Munsell": "2.5YR 5/4", "xC": 0.412, "yC": 0.351, "R": 145, "G": 113, "B": 96},
    {"CapNo": "11",    "Munsell": "7.5R 5/4",  "xC": 0.397, "yC": 0.330, "R": 146, "G": 111, "B": 105},
    {"CapNo": "12",    "Munsell": "2.5R 5/4",  "xC": 0.376, "yC": 0.312, "R": 145, "G": 111, "B": 114},
    {"CapNo": "13",    "Munsell": "5RP 5/4",   "xC": 0.343, "yC": 0.293, "R": 141, "G": 112, "B": 125},
    {"CapNo": "14",    "Munsell": "10P 5/4",   "xC": 0.326, "yC": 0.276, "R": 136, "G": 114, "B": 135},
    {"CapNo": "15",    "Munsell": "5P 5/4",    "xC": 0.295, "yC": 0.261, "R": 129, "G": 117, "B": 143}
]
reference_order = [cap["CapNo"] for cap in cap_data]

def xy_to_uv(x, y):
    denom = 3 + 12 * y - 2 * x
    u = (4 * x) / denom
    v = (9 * y) / denom
    return u, v

def get_uv_coordinates(order, cap_data):
    cap_dict = {cap["CapNo"]: cap for cap in cap_data}
    uv_list = []
    for cap_no in order:
        u, v = xy_to_uv(cap_dict[cap_no]["xC"], cap_dict[cap_no]["yC"])
        uv_list.append((u, v))
    return uv_list

def compute_TES(uv_list):
    tes = 0
    for i in range(len(uv_list) - 1):
        du = uv_list[i+1][0] - uv_list[i][0]
        dv = uv_list[i+1][1] - uv_list[i][1]
        tes += du**2 + dv**2
    return tes

def compute_confusion_angle(uv_list):
    diffs = []
    for i in range(len(uv_list) - 1):
        du = uv_list[i+1][0] - uv_list[i][0]
        dv = uv_list[i+1][1] - uv_list[i][1]
        diffs.append([du, dv])
    if not diffs:
        return 0.0
    diffs = np.array(diffs)
    diffs_centered = diffs - np.mean(diffs, axis=0)
    cov = np.cov(diffs_centered, rowvar=False)
    eigvals, eigvecs = np.linalg.eig(cov)
    idx = np.argmax(eigvals)
    principal_axis = eigvecs[:, idx]
    angle_rad = math.atan2(principal_axis[1], principal_axis[0])
    angle_deg = math.degrees(angle_rad)
    if angle_deg > 90:
        angle_deg -= 180
    elif angle_deg < -90:
        angle_deg += 180
    return angle_deg

def compute_confusion_index(tes, tes_normal):
    return tes / tes_normal

# Compute the reference TES using the correct (reference) order.
uv_reference = get_uv_coordinates(reference_order, cap_data)
TES_normal = compute_TES(uv_reference)
TARGET_NORMAL_TES = 16.0
scale_factor = TARGET_NORMAL_TES / TES_normal

# ====================================
# Color Adjustment Tool Code
# ====================================
class ColorBlindAdjustmentTool:
    def __init__(self, confusion_angle, confusion_index, total_error_score,
                 perfect_tes=16, max_tes=100, max_ci=4.0):
        self.confusion_angle = confusion_angle
        self.confusion_index = confusion_index
        self.total_error_score = total_error_score
        self.perfect_tes = perfect_tes
        self.max_tes = max_tes
        self.max_ci = max_ci
        self.severity = self._calculate_severity()
        self.adjustment_strength = self._calculate_adjustment_strength()

    def _calculate_severity(self):
        ci_clamped = min(max(self.confusion_index, 0.1), self.max_ci)
        ci_component = 1.0 - min(ci_clamped / self.max_ci, 1.0)
        tes_clamped = max(self.total_error_score, self.perfect_tes)
        tes_component = min((tes_clamped - self.perfect_tes) / (self.max_tes - self.perfect_tes), 1.0)
        severity = 0.7 * ci_component + 0.3 * tes_component
        return min(max(severity, 0), 1.0)

    def _calculate_adjustment_strength(self):
        base_strength = np.sqrt(self.severity)
        return 0.1 + 0.9 * base_strength

    def _calculate_confusion_vector(self):
        angle_rad = np.radians(self.confusion_angle)
        return np.array([0, np.cos(angle_rad), np.sin(angle_rad)])

    def adjust_image(self, image, method='lab'):
        if method == 'lab':
            return self._adjust_image_lab(image)
        else:
            raise ValueError("Only 'lab' method is supported.")

    def _adjust_image_lab(self, image):
        lab_image = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
        confusion_vector = self._calculate_confusion_vector()
        perp_angle_rad = np.radians(self.confusion_angle + 90)
        enhancement_vector = np.array([0, np.cos(perp_angle_rad), np.sin(perp_angle_rad)])
        l_channel, a_channel, b_channel = cv2.split(lab_image)
        ab_channels = np.stack([a_channel, b_channel], axis=-1).astype(np.float32) - 128
        projection = np.zeros_like(l_channel, dtype=np.float32)
        for y in range(lab_image.shape[0]):
            for x in range(lab_image.shape[1]):
                ab_val = ab_channels[y, x]
                projection[y, x] = ab_val[0] * confusion_vector[1] + ab_val[1] * confusion_vector[2]
        projection_min = np.min(projection)
        projection_max = np.max(projection)
        if projection_max > projection_min:
            projection = (projection - projection_min) / (projection_max - projection_min) - 0.5
        a_adjusted = a_channel.astype(np.float32)
        b_adjusted = b_channel.astype(np.float32)
        l_adjusted = l_channel.astype(np.float32)
        luminance_enhancement = 0
        if self.total_error_score > self.perfect_tes:
            tes_ratio = min((self.total_error_score - self.perfect_tes) / 84.0, 1.0)
            luminance_enhancement = tes_ratio * 0.2
        for y in range(lab_image.shape[0]):
            for x in range(lab_image.shape[1]):
                adjust = self.adjustment_strength * projection[y, x] * 100
                a_adjusted[y, x] += adjust * enhancement_vector[1]
                b_adjusted[y, x] += adjust * enhancement_vector[2]
                if luminance_enhancement > 0:
                    l_diff = l_adjusted[y, x] - 128
                    l_adjusted[y, x] += l_diff * luminance_enhancement
        a_adjusted = np.clip(a_adjusted, 0, 255)
        b_adjusted = np.clip(b_adjusted, 0, 255)
        l_adjusted = np.clip(l_adjusted, 0, 255)
        adjusted_lab = cv2.merge([l_adjusted.astype(np.uint8),
                                  a_adjusted.astype(np.uint8),
                                  b_adjusted.astype(np.uint8)])
        return cv2.cvtColor(adjusted_lab, cv2.COLOR_LAB2BGR)

# ====================================
# Flask Routes
# ====================================

# Route 1: D-15 Test Page
@app.route("/")
def index():
    # Use the D15 test page (draggable caps)
    pilot = [cap for cap in cap_data if cap["CapNo"] == "pilot"][0]
    draggable_caps = [cap for cap in cap_data if cap["CapNo"] != "pilot"]
    random.shuffle(draggable_caps)
    return render_template_string("""
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>D-15 Color Vision Test</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    #caps-container { display: flex; flex-direction: row; gap: 10px; border: 2px dashed #aaa; padding: 10px; min-height: 80px; align-items: center; overflow-x: auto; }
    .cap { width: 60px; height: 60px; border: 2px solid #333; text-align: center; line-height: 60px; font-weight: bold; color: #fff; cursor: move; user-select: none; filter: brightness(1.25); }
    .cap.fixed { cursor: default; }
    .dragging { opacity: 0.5; }
    .over { outline: 2px dashed #555; }
  </style>
</head>
<body>
  <h1>D-15 Color Vision Test</h1>
  <p>Arrange the caps (the pilot cap is fixed) to match your color perception.</p>
  <div id="caps-container">
    <div id="pilot" class="cap fixed" data-capno="{{ pilot.CapNo }}" style="background-color: rgb({{ pilot.R }}, {{ pilot.G }}, {{ pilot.B }});">
      {{ pilot.CapNo }}
    </div>
    {% for cap in draggable_caps %}
      <div class="cap" draggable="true" data-capno="{{ cap.CapNo }}" style="background-color: rgb({{ cap.R }}, {{ cap.G }}, {{ cap.B }});">
        {{ cap.CapNo }}
      </div>
    {% endfor %}
  </div>
  <button id="submit-btn" style="margin-top:20px;">Submit Arrangement</button>
  <script>
    const container = document.getElementById('caps-container');
    let dragSrcEl = null;
    document.querySelectorAll('#caps-container .cap[draggable="true"]').forEach(function(cap) {
      cap.addEventListener('dragstart', function(e) {
        dragSrcEl = this;
        e.dataTransfer.effectAllowed = 'move';
        this.classList.add('dragging');
      }, false);
      cap.addEventListener('dragenter', function(e) { this.classList.add('over'); }, false);
      cap.addEventListener('dragover', function(e) { e.preventDefault(); return false; }, false);
      cap.addEventListener('dragleave', function(e) { this.classList.remove('over'); }, false);
      cap.addEventListener('drop', function(e) {
        e.stopPropagation();
        if (this.id === "pilot") {
          container.insertBefore(dragSrcEl, this.nextSibling);
          return false;
        }
        if (dragSrcEl !== this) {
          let allCaps = Array.from(container.children);
          let srcIndex = allCaps.indexOf(dragSrcEl);
          let targetIndex = allCaps.indexOf(this);
          if (srcIndex < targetIndex) {
            container.insertBefore(dragSrcEl, this.nextSibling);
          } else {
            container.insertBefore(dragSrcEl, this);
          }
        }
        return false;
      }, false);
      cap.addEventListener('dragend', function(e) {
        this.classList.remove('dragging');
        Array.from(container.children).forEach(function(item) { item.classList.remove('over'); });
      }, false);
    });
    document.getElementById('submit-btn').addEventListener('click', function() {
      let order = [];
      document.querySelectorAll('.cap').forEach(function(div){ order.push(div.getAttribute('data-capno')); });
      fetch("/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ order: order })
      })
      .then(response => response.json())
      .then(data => {
        // Redirect to the image adjustment page with formatted results.
        window.location.href = "/adjust?tes=" + data.TES.toFixed(2) +
                                "&angle=" + data.confusion_angle.toFixed(2) +
                                "&ci=" + Math.round(data.confusion_index);
      });
    });
  </script>
</body>
</html>
    """, pilot=pilot, draggable_caps=draggable_caps)

# Route 2: Process D15 Test Submission
@app.route("/submit", methods=["POST"])
def submit():
    data = request.get_json()
    order = data.get("order")
    if not order or len(order) != len(cap_data):
        return jsonify({"error": "Invalid order length."}), 400
    uv_order = get_uv_coordinates(order, cap_data)
    tes = compute_TES(uv_order)
    confusion_angle = compute_confusion_angle(uv_order)
    scaled_tes = scale_factor * tes
    confusion_index = compute_confusion_index(tes, TES_normal)
    results = {"TES": scaled_tes, "confusion_angle": confusion_angle, "confusion_index": confusion_index}
    return jsonify(results)

# Route 3: Image Adjustment Page using the provided interface (modified)
@app.route("/adjust")
def adjust():
    tes = request.args.get("tes", type=float)
    angle = request.args.get("angle", type=float)
    ci = request.args.get("ci", type=float)
    # Render the modified interface.html template.
    return render_template("interface.html", tes=tes, angle=angle, ci=ci)

# Route 4: Process the Uploaded Image and Adjust It
@app.route("/adjust-image", methods=["POST"])
def adjust_image():
    angle = float(request.form['confusion_angle'])
    ci = float(request.form['confusion_index'])
    tes = float(request.form['total_error_score'])
    # For now, we use the Lab method as in your tool.
    method = request.form.get('method', 'lab')
    file = request.files['image']
    npimg = np.frombuffer(file.read(), np.uint8)
    img = cv2.imdecode(npimg, cv2.IMREAD_COLOR)
    tool = ColorBlindAdjustmentTool(confusion_angle=angle, confusion_index=ci, total_error_score=tes)
    adjusted_img = tool.adjust_image(img, method)
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".jpg")
    cv2.imwrite(temp_file.name, adjusted_img)
    return send_file(temp_file.name, mimetype='image/jpeg')

if __name__ == '__main__':
    app.run(debug=True)
